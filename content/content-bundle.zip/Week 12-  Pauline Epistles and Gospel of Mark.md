-   The overwhelming consensus is that Paul wrote the following seven letters: Romans, 1 Corinthians, 2 Corinthians, Galatians, Philippians, 1 Thessalonians, and Philemon. Three letters are disputed, though they may have been written during Paul's life or shortly after his death.

PAGE 3

-   The Pastoral Epistles are believed to be fictitious letters written by Paul to Timothy and Titus. They are especially concerned with the "shepherding" of the churches discussed in them.

PAGE 4

-   The Pauline Epistles contain non-Pauline vocabulary and usage, and odd phrases not found elsewhere. The presence of "the saying is sure" in all three letters strongly suggests that all three were composed by the same author.

PAGE 6

PAGE 7

-   Luke Timothy Johnson has made a case for at least part of the Pastoral Epistles being written by Paul. He argues that the PEs are not quite as similar to one another as scholars tend to assume.

PAGE 9

-   Women can do everything men can do in a religious community, except preach and speak from a position of authority. They can have most other leadership roles, however, including children's programs, women-only groups, and music.

PAGE 10

-   The pastorals and undisputed letters on women teach that a woman is to learn in silence with full submission, and that she will be saved through childbearing.

PAGE 11

PAGE 12

-   God created humankind in his image, male and female he created them, and blessed them, saying to them, "Be fruitful and multiply, fill the earth and subdue it", and to have dominion over all living things.

PAGE 13

-   Romans 5:12-14 says that death exercised dominion over all people from Adam to Moses, even over those whose sins were not like the transgression of Adam.

PAGE 14

-   Women should be silent in the churches and ask their husbands at home if they want to know anything.

PAGE 15

-   Paul recommended Phoebe to the church at Cenchreae and asked them to help her. He also mentioned Prisca and Aquila, who risked their necks for his life, and Mary, who worked very hard among you.
=================================
# Mark's Gospel

-   We are starting the last major unit of the class, and we are going to be looking at the gospels as distinctive literary compositions. The introductions in a study Bible will be very helpful for orienting you to these things before you start reading.

PAGE 4

-   The authorship of the four NT Gospels is not clear. Some traditions are accurate, but it's difficult to square all of this information with the evidence found in the Gospels themselves.

PAGE 5

-   In none of the Gospels does the author identify himself or herself by name. The names attached to two of the four Gospels are not exactly very prominent figures in early Christianity.

PAGE 6

-   Mark was Peter's interpreter, and wrote accurately all that he remembered of the things said or done by the Lord, though not in order. He did nothing wrong in thus writing down single points as he remembered them.

PAGE 7

-   Papias's comments about Mark indicate that Mark is not a disciple/apostle, but that the Gospel has an apostolic connection since Mark is supposed to have been the Apostle Peter's interpreter (or secretary? or scribe).

PAGE 8

-   Through Silvanus, a faithful brother, I have written this short letter to encourage you and to testify that this is the true grace of God. Your sister church in Babylon sends you greetings, and so does my son Mark.

PAGE 9

-   Paul and Barnabas parted company after some days because Paul did not want to take John called Mark with them. Paul chose Silas and went through Syria and Cilicia, strengthening the churches.

PAGE 10

-   Aristarchus and Mark, cousins of Barnabas, greet you. Do your best to come to me soon, because Demas has deserted me and gone to Thessalonica, Crescens has gone to Galatia, Titus to Dalmatia, and only Luke is with me.

PAGE 11

-   Peter's calling is not as central as we might expect. He was called by Jesus after he saw his brother Andrew casting a net into the sea and after John saw two of his disciples following him.

PAGE 12

-   Jesus asked the disciples who they said he was, and Peter answered, "You are the Messiah." He sternly ordered them not to tell anyone about him, and he gave Peter the keys of the kingdom of heaven.

PAGE 13

-   Jesus began to teach his disciples that the Son of Man must undergo great suffering, be rejected by the elders, the chief priests, and the scribes, and be killed, and after three days rise again. Peter took him aside and began to rebuke him, but Jesus rebuked Peter and said, "Get behind me, Satan!"

PAGE 14

-   One of the servant-girls of the high priest came by and said that Peter was with Jesus, the man from Nazareth. Peter denied it and went out into the forecourt, where the cock crowed again, and Peter broke down and wept.

PAGE 15

-   The Gospel of Mark is a rather unexpected figure to give as the author of a Gospel, and it is hard to believe that everything that Peter said about Jesus was included in this rather short Gospel.

PAGE 16

-   The disciples are idiots, and they consistently misunderstand what Jesus is telling them. Mark has a rough and unpolished literary style, and many strange passages that don't make any sense.

PAGE 17

-   Jesus said to them, "Why are you talking about having no bread?" and said, "Do you not yet understand?" Some difficult Markan passages.

PAGE 18

-   Mark 13:14-19: Some difficult Markan passages: 14 When you see the desolating sacrilege set up where it ought not to be, those in Judea must flee to the mountains; 15 the one on the housetop must not go down or enter the house to take anything away; 16 the one in the field must not turn back to get a coat.

PAGE 20

-   A passer-by was forced to carry Jesus' cross, and Jesus warned that the persecuted Christian community must flee to the mountains if they saw the desolating sacrilege set up where it ought not to be.

PAGE 21

-   To get rid of the report, Nero fastened the guilt and inflicted the most exquisite tortures on a class hated for their abominations, called Christians by the populace. They were covered with the skins of beasts, torn by dogs and perished, or were nailed to crosses, or were doomed to the flames and burned.

PAGE 22

-   The people of the church in Jerusalem were told to leave the city and live in a town called Pella, but the judgment of God overtook them and totally destroyed that generation of impious men.