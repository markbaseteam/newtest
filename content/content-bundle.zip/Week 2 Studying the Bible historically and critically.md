"Inerrancy" V. "Inspiration"

[[Inerrancy]]: Bible contains no errors or contradictions of any kind (held by evangelical Christians, southern baptist, church of Christ, non-denominational, etc.)


Inspiration: The Bible is inspired by God, but contains mistakes because it is written by human beings.

Professional Biblical Scholar:
- Can read thd Bible in its original languages.

- Have received a degree that trains biblical scholars
- Rigorous training, including language work, exams, and completion of a dissertation
- Require a Statement of Faith: believe the bible is true (Job security depends on it)

Ehrman decided to study the New Testament:
- His Statement of Faith was very strong, wants to learn more about the Bible
- This dedication to the biblical text was what gave rise to the modern academic study of the Bible in the first place.

What methods to scholars use to dissect historical text?
- Historical criticism is completely different from devotional approach
- Historical Critical approach has a different set of concerns and poses a different set of questions
	- What does the Bible mean?
	- Who were the actual authors of the Bible
	- What circumstances were met while they were written?
	- Did perspectives differ from one another?
	- Authors have different perspectives? From their sources and from one another? Internal contradictions? Original context is not what they are taken to mean today?Our interpretations of Scripture involve taking its words out of context and distorting its message?
	- Not just about 'historicity' (whether it is true or not)
	- Historical Criticism v [[Inerrancy]]
		- In conflict
		- Historical critic would say that Luke's Christmas story gives good reasons to be doubtful about accuracy of what Luke claims
Synopsis of the Four Gospels
All four gospels agree that on the third day after Jesus' crucifixion and burial, Mary Magdalene went to the tomb and found it empty, but on virtually every detail they disagree.

  
 “Who actually went to the tomb? Was it Mary alone (John 20:1)?  
Mary and another Mary (Matthew 28:1)? Mary Magdalene, Mary  
the mother of James, and Salome (Mark 16:1)? Or women who  
had accompanied Jesus from Galilee to Jerusalem—possibly  
Mary Magdalene, Joanna, Mary the mother of James, and ‘other  
women’ (Luke 24:1; see 23:55)?”  
And when you do read a passage from the gospels in a  
synopsis, what do you see?

 “Had the stone already been rolled away from the tomb (as in Mark  
16:4) or was it rolled away by an angel while the women were there  
(Matthew 28:2)? Whom or what did they see there? An angel  
(Matthew 28:5)? A young man (Mark 16:5)? Two men (Luke 24:4)?  
Or nothing and no one (John)?...Then, do the women tell the  
disciples what they saw and heard (Matthew 28:8), or do they not  
tell anyone (Mark 16:8)? If they tell someone, whom do they tell?  
The eleven disciples (Matthew 28:8)? The eleven disciples and  
other people (Luke 24:8)? Simon Peter and another unnamed  
disciple (John 20:2)? What do the disciples do in response? Do  
they have no response because Jesus immediately appears to  
them (Matthew 28:9)? Do they not believe the women because it  
seems to be ‘an idle tale’ (Luke 24:11)? Or do they go to the tomb  
to see for themselves (John 20:3)?”

  
Inerrancy doesn’t work, and a Christianity based on inerrancy  
simply pretends that this reality doesn’t exist.  
2. We must read each biblical author for himself. Don’t read to see  
“what the Bible says.” Read to see what Mark says, what  
Matthew says, etc. Each book has its own viewpoint.  
3. These contradictions make the task of historical reconstruction  
difficult, sometimes very difficult. But not impossible. We just  
need to remember that these aren’t the sorts of historical  
records that we might expect them to be.