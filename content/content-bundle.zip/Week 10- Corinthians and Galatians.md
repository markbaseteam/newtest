-     
    When people come together to eat the Lord's Supper, they treat it like a typical Greco-Roman banquet. This shows contempt for the church of God and humiliates those who have nothing.

PAGE 3

-   Some problems seem to have been related to the appearance of several charismatic missionaries. Paul appeals to the brothers and sisters to be in agreement and to be united in the same mind and the same purpose.

PAGE 4

-   A number of problems seem to have the same underlying issue, one that Paul may have inadvertently caused through his descriptions of baptism.

PAGE 6

-   I can eat meat sacrificed to idols, because I know that those gods don't really exist! There is only one God, the Father, and one Lord, Jesus Christ.

PAGE 7

-   I can eat meat sacrificed to idols, because I know that those gods don't really exist! Some people, however, have become so accustomed to idols until now, that they still think of the food they eat as food offered to an idol, and their conscience is defiled.

PAGE 8

-   A man is living with his father's wife, and you are arrogant. You are to hand this man over to Satan for the destruction of the flesh, so that his spirit may be saved in the day of the Lord.

PAGE 9

-   If you don't know that your bodies are members of Christ, don't make them members of a prostitute. Anyone united to the Lord becomes one spirit with him, but anyone united to a prostitute becomes one body with her.

PAGE 10

-   A "new creation" should have his own wife and his own husband, and should not deprive one another except perhaps by agreement for a set time, to devote yourselves to prayer, and then come together again.

PAGE 11

-   Paul wishes that all were as he is, but each has a particular gift from God. He says that the unmarried and widows should remain unmarried if they are not practicing self-control, and that the married should not divorce their husbands.

PAGE 12

-   Paul's advice to virgins: stay as you are, because the time is short. If you marry, you do not sin, but those who marry will experience distress in this life, and he would spare you that.

PAGE 13

-   Love is patient, love is kind, love is not envious or boastful or arrogant or rude, it rejoices in the truth, bears all things, believes all things, hopes all things, endures all things, but prophecies, tongues, and knowledge will come to an end.

PAGE 15

-   Though it's difficult to be certain, Paul's message had liberated people from the world's usual ways of doing things. But people interpreted it differently after he left the community.

PAGE 16

-   Paul tells women to wear veils, because Christ is the head of every man, and the husband is the head of his wife, and God is the head of Christ. If a woman will not veil herself, she should cut off her hair, but she should wear a veil. It is proper for a woman to pray to God with her head uncovered. Her hair is her glory.

PAGE 17

-   Paul knows Jesus' "words of institution" from the Last Supper. He says that if we eat and drink without discerning the body, we eat and drink judgment against ourselves, and this is why many of you are weak and ill, and some have died.

PAGE 18

-   Paul told the Corinthians that Jesus died for their sins, was buried, and was raised on the third day in accordance with the scriptures. He appeared to Cephas, the twelve, and then to more than five hundred brothers and sisters.

--------------------------------
==========================



PAULS most confrontational letter

- If Gentiles are required to adopt Jewish practices in order to be members of the Christian Church, that means that Christ's sacrifice on the cross wasn't sufficient.
- Salvation doesnt come from good works (not entirely what Paul is saying)

-   If Paul is writing to "ethnic Galatians", why did he choose to do missionary work there, how much would he have known about their religious background, and what became of the Galatian Christian community after Paul's letter?


-   After fourteen years I went up to Jerusalem with Barnabas and Titus, and laid before them the gospel that I proclaim among the Gentiles. Titus was not compelled to be circumcised, though he was a Greek.



-   After some individuals came down from Judea and taught the brothers that they needed to be circumcised, Paul and Barnabas were appointed to go up to Jerusalem to discuss this question with the apostles and the elders.



-   Galatians 2:15-21: We ourselves are Jews by birth and not Gentile sinners, but we know that a person is justified not by the works of the law but through faith in Jesus Christ. If we ourselves have been found to be sinners, then Christ is not a servant of sin.