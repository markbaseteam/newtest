- All scholars agree that there are some sort of literary relationship (one of them might be borrowing from one another)

- The Two-Source Hypothesis (Matthew and Luke using both Mark and Q as their major sources) is not a perfect solution to the Synoptic Problem (Same perspective). Less problematic as an explanation than any other hypothesis.

- If the Two-Source Hypothesis is basically correct, that means that at least two out of the three Synoptic Gospels were not written by eyewitnesses
- Luke said he is not an eyewitness, he was a follower of the Apostle Paul who was not an eyewitness either.
- The Two-Source Hypotehesis is much more damaging for Matthew, since he is claimed to ber one of the Twelve Disciples. If Matthew was an eyewitness, why would he copy material from other Gospels?
- We do not know why John is different from the Synoptics. 