DIsclaimer: Some of these (very few) contain some copy/pasted material since this was intended to be personal all-access notes for myself to refer to!

[[Week 1]]:
[[Week 2 Studying the Bible historically and critically]]:
[[Week 3 Video and Rome]]:
[[Week 4-Jewish history and the mythology of Israel]]
	[[Gospels as Historical Sources]]
[[Week 5- Relationship between Gospels]]
[[Week 6-Three (More) Big Ideas about the Historical Jesus ]]
[[Week 7- Historical Jesus]]
[[Week 8 Death and Resurrection of Jesus]]
[[Week 9- Video 2 and Paul and Corinthians]]
[[Week 10- Corinthians and Galatians]]
[[Week 11- Philemon]]
[[Week 12-  Pauline Epistles and Gospel of Mark]]
[[Week 13- MATTHEW GOSPEL]]
[[Week 14- LUKE and Revelations]]
