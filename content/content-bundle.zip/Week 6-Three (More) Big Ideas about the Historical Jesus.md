
- ## Idea 1
- Criteria of authenticity of "historical Jesus":
	- Multiple attestation
	- embarassment
		- Both of these apply to His crucifixion

## Idea 2
- We need to make a choice between privileging the Synoptic Gospels or the Gospel of John
- Because the portrayals are so radically different
- Synoptics:
	  Parables
	  Exorcisms
	  Jesus talks mostly about Kingdom of God
	  Jesus is quite cryptic about who he is (Messiah, Son of God, prophet)
- John:
	- No Parables
	- No Exorcisms
	- Jesus talks mostly about Himself
	- Jesus is clear that he's a pre-existent divine being who has descended to earth


## Idea 3
- Historical Jesus will depend on how you evaluate the miraculous events in which Jesus has participated in