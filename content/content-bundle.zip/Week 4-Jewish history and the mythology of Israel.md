#### Jewish history and the mythology of Israel


Myths: Sacred stories that explain how things came to be

YHWH is the God of Israel, tetragrammation (Greek for "four letter")

"Adonai" my Lord, or "Ha-Shem" the name 
These have been used as substitutes.

Name traditionally revealed to Moses in the burning bush episode, but some sources in the Bible claim that the name was revealed much earlier

YHWH's Covenant with the Patriarchs
- Abraham
- Isaac (and Ishmael)
- Jacob, who receives a new name (Israel)
- 12 sons of Jacob become 12 tribes of Israel (10 northern tribes, 2 southern tribes)

(This is the book of Genesis)
Then comes the Exodus:
- Moses, Egypt, slavery, plagues, Red Sea, wandering in the desert for 40 years, and conquest of the land of Canaan.

(Historicity of all of these people and events is very uncertain and pretty unlikely)

##### What do we know about the history of the Jewish people?
The Book of Exodus and the conquest of the land of Israel are very questionable

Yet, by the thirteenth centurty BCE, there was a group of tribes living in what we now call the land of Israel that banded together into a confederation

They united under a monarchy to protect themsevles against neighboring tribes like the Philistines.

During the reigns of Saul, David, and Solomon (1020-920 BCE), the kingdon became a regional people and also centered its religious life around Jerusalem and its temple devoted to the god these tribes worshipped, YHWH.

After about 50 years, the Babylonian Empire was conqured by the Persian Empire. The Persians permitted some of the Jews to return home; they rebuilt Jerusalem and the Temple and begin to re-establish the religious life of the community.

True independence was gone. The homeland of the Jews (along with the entire eastern Mediterranean more generally) changed hands from one imperial power to another in the following centuries: the Persians, Alexander the Great, his Hellenistic successors, and the Romans.

Second century BCE, the jews successfully revolted against the Hellenistic Seleucid kingdom, after being provoked by Seleucid suppression of Jewish religious practices.

Self-rule returned to the Jews for a little over 100 years (160-40 BCE). But was a tiny state and relied on an alliance with Rome to ward off much more powerful neighbors (like the Parthian Empire)

Wasn't a return to the "golden age" of David and Solomon.
Furthermore, there was a great deal of unhappiness in Jewish society about the corrupt ruling practices of the Hasmoneans.

Rome was an ally at first, but by the middle of the first century BCE, they were clearly the ones calling the shots in Israel, even if the nation was still independent

Rome was a "Client Kingdom" which meant that it wasnt a Roman province, but rather a buffer state on the periphery of the Roman Empire whos ruler, King Herod, was hand-picked by the Romans to keep the peace and to keep the Parthian Empire at bay. 

Herod did a good and brutal job of keeping the peace. When he died, the Romans did not think his sons were up to the task. So the Land became an official province of the Roman Empire, Judea.

Terminology: Judah -> Judea -> Jew/Jewish/Judaism 
Derived from the name of one of the tribal leaders. The other designation for the people, "Israel", was given to one of the patriarchs, Jacob, and means "wrestles with God." 

During the first century CE, life under Roman rule became increasingly difficult for the Jews. The governors assigned to Judea were generally pretty terrible.

Noboby likes being ruled by a foregin power, but the Roman authorities in Israel became more brutal and less tolerant of Jewish religious idiosyncrasies.

There were multiple revolts throughout the first century, but the boiling point came in the year 66, when rebel Jewish forces took control of Jerusalem

The Romans came back with a much larger army, and burned Jerusalem and its Temple to the ground in the year 70. Perhaps a million Jews died during this conflict, the "Jewish War" or the "Jewish Revolt".

The Wailing Wall (Western Wall)

	Built on a hill- uneven terrain
	Very holy islamic site
- Jesus cleanses the temple, out in the open
- The jewish war and destruction of jerusalem and temple, 40 years after Jesus death

Thursday:
- Segments of Jewish society felt strong regarding their independance, there were two more revolts 
	- In Diaspora (Jewish communities outside the land of Israel)
	- In Bar Kochba Revolt in 132-135 in Israel
- There is no more jewish community in Alexandria after 117
- Romans completely destroyed Jerusalem and rebuilt it as a pagan city (temple to Zerus and the Emperor Hadrian where Jewish Temple used to stand)
- Where are the Christians in this?
	- We dont know but we can assume that they could be lumped together with Jews
- The Pharisees survive after the Temple is destroyed
	- Can be Jesus' adversaries
	- Were not priests, but laypeople who tried to apply as much of the Torah to everyday life as they could. 
- Orthodoxed Jews are traditional
- Conservative are kind of in the middle
- Reformed jews that are more secular
Pharisees became known as rabbis, studying the Torah and how to apply its laws
- rabbinic Judaism- where all modern forms are descended

- Inaccurate to look at rabbinic Judaism as Christianity's parent.
	- Both developing at the same time, out of the range of Judaisms that were in existence prior to the destruction of the Temple
- The position of the synagogue (gathering together) becomes more important as a place for Jews to meet and workship/study the Torah together.
- Unlike the Temple, synagogues could exist anything, and increasingly to spring up wherever Jews live
- 
## Jews had it bad
- Only had independence for a few short periods of time
- They are a solid regional power at best during the united monarchy, but are no superpower
- Are under the boot of one empire after another (because of their strategic location)
- Under the Romans, things get worse- Rule gets increasingly brutal, there are several disastrous revolts, and their holy city of Jerusalem is wiped off the map
## Why they kept going
- God's conenantal relationship with Israel
	- That the God of all creation decided to make Jews his chosen people who are destined for greatness
- Believed that God will soon intervene history to set Israel free (Passover). Accompanied by expectation of a Messiah, a new leader sent by God who will liberate Israel and make it the most powerful nation in the world

[[Gospels as Historical Sources]]
