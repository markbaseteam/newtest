-   Matthew is considered the most Jewish of the four gospels, because it shows how Jesus' life fulfilled Jewish scripture.

-   His genealogy of Jesus is more Jewish than Luke's, since it traces J's lineage back to Abraham, and mentions four women found in the HB.

-   After faith has come, we are no longer subject to a disciplinarian, for in Christ Jesus you are all children of God through faith. Therefore, whoever breaks one of the least of these commandments and teaches others to do the same will be called least in the kingdom of heaven.

-   Matthew was a Jewish-Christian author who lived in a Christian community that was attracting more and more Gentiles. He was concerned with putting as much of the Law into the practice of his everyday life as possible.

-   Since Matthew's community seemed to be strict about the observance of the Jewish Law, they probably got along fine with other communities of Jews around them.

-   After the destruction of the Temple in 70 CE, a group of rabbis started having more influence over society, and tried to put as much of the Law into practice.

-   Jesus said to the crowds and to his disciples that the scribes and the Pharisees sit on Moses' seat, but they do not practice what they teach. They love to have the place of honor at banquets and the best seats in the synagogues.

-   According to the Two-Source Hypothesis, the majority of the material in Matt is from Mark and Q.

-   Scholars don't think that M was a complete written document, and it probably came from lots of different places: oral traditions, written sources Matt had access to, and some passages that he probably invented himself.

-   The entire infancy narrative, stories and sayings about Peter, Judas hanging himself, Pilate's wife having a dream about Jesus, the zombie-producing earthquake, guards at the tomb of Jesus, and more are in Matthew.

-   Matthew was written after 70, after the destruction of Jerusalem and the Temple. It is unclear whether Papias is talking about the gospel we know as Matthew, or about Q, and whether it was written in Hebrew or Aramaic.

-   Matthew cares more than any other gospel writer about showing how events in Jesus' life fulfilled passages from the Jewish Bible. The Septuagint is the Greek translation of the Hebrew Bible, and Matthew's citations generally tend to be closer to the LXX version than the original Hebrew.

-   The LXX sometimes translates a Hebrew word with a Greek word that doesn't actually mean the same thing, or translates literally an expression that makes sense in Hebrew Bible not in Greek.

-   The Septuagint (LXX) is important for understanding Matthew's Gospel because Matthew cares more than any other gospel writer about showing how events in Jesus' life fulfilled passages from the Jewish Bible.

-   Matthew cares more than any other gospel writer about showing how events in Jesus' life fulfilled passages from the Jewish Bible. His scriptural fulfillment citations are sometimes a bit...odd.

-   When they reached Bethphage, at the Mount of Olives, Jesus sent two disciples to get a donkey and a colt, and they put their cloaks on them and brought them to him.

-   Joseph took the child and his mother by night and went to Egypt, where he remained until the death of Herod. This was to fulfill what had been spoken by the Lord through the prophet.

-   Matthew cites Isa 7:14 in his infancy narrative, but the Hebrew text of this verse says that Mary would bear a son, and Joseph would name him Jesus, because he would save his people from their sins.

-   The Hebrew word used here for "young woman" is almah, and while it could potentially imply a virgin, it really emphasizes that she's young, as opposed to old.

-   If the author of Isaiah had wanted to make it crystal clear that a virgin was conceiving, he could have used the Hebrew word bethulah.

-   Matthew used a Greek word that has a stronger connotation of "virgin" than the original Hebrew word for "young woman" in Isa 7:14, but the LXX translator didn't necessarily think that this verse was a prophecy of a miraculous conception.

-   Matthew's scriptural citations are potentially uncomfortable. Should we fault him for ignoring the original context and meaning of the passages?

-   Matthew's scriptural citations may be in "bad faith", but should we fault him for this practice?