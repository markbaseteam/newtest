- ### What were the teachings of the historical Jesus
	- The Kingdom of God
	- The Jewish Law
	- The ethics of wealth and poverty
- 
- The majority of scholars think there's very little of historical value in birth narratives, and the stories don't agree. Apostle Paul says nothing about Jesus' birth, and Gospel of John has an interesting exchange pertaining to this.


-   The overwhelming majority of scholars think there's very little of historical value in the birth narratives, and the stories don't agree. There are a few intriguing agreements between Matt and Luke, especially that Jesus was conceived prior to his parents' marriage.



-   Scholars think there's very little historical value in the birth narratives, and the stories don't agree between Matt and Luke. There are a few intriguing agreements between Matt and Luke, especially that Jesus was conceived prior to his parents' marriage.



-   Jesus came to Galilee, preaching the good news of God, and saying that the kingdom of God has come near. He said that whoever hears and does not act on his words is like a man who built a house without a foundation.


-   Jesus said that if he casts out demons by the finger of God, then the kingdom of God has come to you. The Pharisees asked when the kingdom of God would come.

-   Jesus compared the kingdom of God to a mustard seed, and said that it grows up to be the greatest of all shrubs, and puts forth large branches.


-   When Jesus was alone, those around him asked him about the parables. Jesus replied that he taught in parables so that those outside would "look, but not perceive" and "listen, but not understand" and "not turn again and be forgiven".



-   Jesus answered the Pharisees that it is not lawful to do good or to do harm on the sabbath, to save life or to destroy it, and then healed a man whose right hand was withered. The Pharisees were furious and discussed with one another what they might do to Jesus.



-   Jesus said that he had come to fulfill the law and the prophets, and that whoever breaks one of the least of these commandments and teaches others to do the same will be called least in the kingdom of heaven. You have heard that it was said to those of ancient times, 'You shall not murder', but I say to you that if you are angry with a brother or sister, insult a brother or sister, or say, 'You fool,' you will be liable to the hell of fire.



-   Jesus' attitude toward wealth was that those who are poor, hungry, or weeping now, will laugh, and those who are rich, full, or laughing now, will mourn and weep.





-   A man asked Jesus, "Good Teacher, what must I do to inherit eternal life?" Jesus said, "You lack one thing; go, sell what you own, and give the money to the poor, and you will have treasure in heaven." Jesus said that it was hard for those who had wealth to enter the kingdom of God, but that it was easier for a camel to go through the eye of a needle.

- Romans and some Jewish authorities were in charge of the Jerusalem Temple
	- Because crucifixion was a Roman punishment for rebellion against the Empire, and was frequently deployed in Judea during the first centry CE