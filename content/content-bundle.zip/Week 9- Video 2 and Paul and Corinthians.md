- What is Paul trying to communicate to the audience and why might he be writing in the first place
- -   When you do the Reading in JANT, don't feel like you need to read all the footnotes. Instead, read the actual text of the book(s) we're covering for that day, and see if the notes help out in any way.

PAGE 2

-   Why should you care about the Apostle Paul? Because he is arguably more important to Christianity than Jesus, and he gives us the earliest writings in the NT.

PAGE 3

-   The Apostle Paul's letters provide us with the opportunity to see how early Christian communities functioned on a daily basis, and they are meant to put out fires. They are also a source of endless fascination, since virtually every interpretative issue is up for grabs.

PAGE 5

-   The Apostle Paul says mean things about people he doesn't like, and calls out another apostle in public for hypocrisy. There is a fierce debate within many churches today whether Paul is "appealing" or "appealling" in regards to numerous pertinent social issues.

PAGE 7

On Women’s Leadership in

-   Church - Good Paul: "There is no longer Jew or Greek, there is no longer slave or free, there is no longer male and female"; - Bad Paul: "Women should be silent in the churches";

PAGE 8

-   Paul tells Philemon to obey his masters with fear and trembling, in singleness of heart, as he obeys Christ.

PAGE 9

-   On homosexuality, Paul isn't a big fan of sex in general, and he says that men committed shameless acts with men and received the due penalty for their error.

PAGE 10

reconstruct his life and career. If all we had was his letters, we would be quite unsure about what order the letters were written in.

-   Paul gives us some information about his background, but not enough to form a coherent picture. There are no NT writings that narrate Paul's career.

PAGE 11

-   Paul's missionary work is described in Acts, but we don't have an absolute chronology. It would be helpful to have a precise date for one event.

PAGE 13

-   The Gallio Inscription helps us to date Paul's ministry because it tells us the year the inscription was made and that Gallio was the proconsul for the year in which the inscription was made.

PAGE 15

-   Acts presents Paul as first taking his message to the Jews, but the evidence from Paul's letters suggests his ministry was overwhelmingly focused on bringing his "gospel" to the Gentiles.

PAGE 16

-   According to Acts 8:1-3 and 9:1-31, Paul was persecuting Christians in and around Jerusalem when Jesus appeared to him in a blinding flash and told him to enter the city. He joined the Christian community in Damascus and stayed there until Jews threatened his life.

PAGE 18

-   Galatians on Paul's conversion: "I received the gospel not from a human source, nor was I taught it." I was violently persecuting the church of God and tried to destroy it. When God revealed his Son to me, I went away into Arabia and afterwards returned to Damascus, and after three years I went up to Jerusalem to visit Cephas, but did not see any other apostle except James the Lord's brother.

PAGE 19

Acts vs. Galatians on Paul’s

-   Paul integrates himself in the Christian community in Damascus right after his conversion, whereas Paul stays away from Christian communities as long as possible.

PAGE 20

-   Acts vs. Galatians on Paul's conversion - Biggest differences include: Paul departs Damascus and goes to Jerusalem "after some time had passed." Gal: Paul doesn't go to Jerusalem for three years after his conversion.

PAGE 21

-   Acts and Galatians agree that Paul persecuted Christians before his conversion, but there are differences. Is Luke giving us the accurate version?

PAGE 22

-   Paul's conversion most likely happened in Damascus, not Jerusalem/Judea. He likely became part of an existing Christian community in Damascus before he started talking to Christians in Jerusalem.

PAGE 23

-   Paul's mission is totally separate from the leaders of the Jerusalem Church, and he had to fight an uphill battle for credibility.

PAGE 24

-   We have to use Acts as a historical source for Paul's life, as we have no other resources.

-     
    When people come together to eat the Lord's Supper, they treat it like a typical Greco-Roman banquet. This shows contempt for the church of God and humiliates those who have nothing.

PAGE 3

-   Some problems seem to have been related to the appearance of several charismatic missionaries. Paul appeals to the brothers and sisters to be in agreement and to be united in the same mind and the same purpose.

PAGE 4

-   A number of problems seem to have the same underlying issue, one that Paul may have inadvertently caused through his descriptions of baptism.

PAGE 6

-   I can eat meat sacrificed to idols, because I know that those gods don't really exist! There is only one God, the Father, and one Lord, Jesus Christ.

PAGE 7

-   I can eat meat sacrificed to idols, because I know that those gods don't really exist! Some people, however, have become so accustomed to idols until now, that they still think of the food they eat as food offered to an idol, and their conscience is defiled.

PAGE 8

-   A man is living with his father's wife, and you are arrogant. You are to hand this man over to Satan for the destruction of the flesh, so that his spirit may be saved in the day of the Lord.

PAGE 9

-   If you don't know that your bodies are members of Christ, don't make them members of a prostitute. Anyone united to the Lord becomes one spirit with him, but anyone united to a prostitute becomes one body with her.

PAGE 10

-   A "new creation" should have his own wife and his own husband, and should not deprive one another except perhaps by agreement for a set time, to devote yourselves to prayer, and then come together again.

PAGE 11

-   Paul wishes that all were as he is, but each has a particular gift from God. He says that the unmarried and widows should remain unmarried if they are not practicing self-control, and that the married should not divorce their husbands.

PAGE 12

-   Paul's advice to virgins: stay as you are, because the time is short. If you marry, you do not sin, but those who marry will experience distress in this life, and he would spare you that.

PAGE 13

-   Love is patient, love is kind, love is not envious or boastful or arrogant or rude, it rejoices in the truth, bears all things, believes all things, hopes all things, endures all things, but prophecies, tongues, and knowledge will come to an end.

PAGE 15

-   Though it's difficult to be certain, Paul's message had liberated people from the world's usual ways of doing things. But people interpreted it differently after he left the community.

PAGE 16

-   Paul tells women to wear veils, because Christ is the head of every man, and the husband is the head of his wife, and God is the head of Christ. If a woman will not veil herself, she should cut off her hair, but she should wear a veil. It is proper for a woman to pray to God with her head uncovered. Her hair is her glory.

PAGE 17

-   Paul knows Jesus' "words of institution" from the Last Supper. He says that if we eat and drink without discerning the body, we eat and drink judgment against ourselves, and this is why many of you are weak and ill, and some have died.

PAGE 18

-   Paul told the Corinthians that Jesus died for their sins, was buried, and was raised on the third day in accordance with the scriptures. He appeared to Cephas, the twelve, and then to more than five hundred brothers and sisters.