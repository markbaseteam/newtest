






-   Biblical scholars do not regard Revelation as a prediction of how the world will end, but as a distinct literary genre.

-   Daniel had a dream in which he saw the four winds of heaven stirring up the great sea, and four great beasts coming up out of the sea, different from one another. One of the beasts had its wings plucked off and a human mind was given to it.

-   A beast appeared that looked like a bear, had three tusks in its mouth among its teeth, had four wings of a bird on its back and four heads, and was given dominion. A fourth beast appeared, terrifying and dreadful and exceedingly strong.

-   Apocalypse is a book of prophecy that shows how events in heaven affect life on earth. It is also a book that shows the future history of the world. A third of the earth was burned up, a third of the trees were burned up, all green grass was burned up, and a third of the sea became blood, a third of the living creatures in the sea died, and a third of the ships were destroyed.

-   A third of the earth was burned up, a third of the trees were burned up, all green grass was burned up, and a third of the sea became blood, a third of the living creatures in the sea died, and a third of the ships were destroyed.

-   Revelation is unusual because its author is "John," and this appears to be his real name, since Yohanan was an extremely common ancient Jewish name. Many parts of the Church didn't accept it until relatively late (4th or 5th century).

-   Rev's author John saw a beast rising out of the sea, and the whole earth followed it. They worshiped the dragon, for he had given his authority to the beast, and they calculated the number of the beast, and it is six hundred sixty-six.

-   A woman was sitting on a scarlet beast with seven heads and ten horns, adorned with gold and jewels and pearls, and holding a golden cup full of abominations and the impurities of her fornication. She was drunk with the blood of the saints and the blood of the witnesses to Jesus.

-   Revelation 17:1-6 describes a woman sitting on a scarlet beast full of blasphemous names, adorned with gold and jewels and pearls, and holding a golden cup full of abominations and the impurities of her fornication. The woman was drunk with the blood of the saints and the witnesses to Jesus.

-   To assure the persecuted faithful that God has not forgotten about their plight, he shows them thrones, and the souls of those who were beheaded for their testimony to Jesus and for the word of God come to life and reign with Christ a thousand years.

-   The white horse's rider is called Faithful and True, and in righteousness he judges and makes war. He has a name inscribed that no one knows but himself, and the armies of heaven are following him on white horses.

-   The beast and the kings of the earth were captured, along with the false prophet who had performed signs in its presence to deceive those who had received the mark of the beast and those who worshiped its image. All the birds were gorged with their flesh.

-   The Rapture is found nowhere in Revelation, but instead in Paul's First Letter to the Thessalonians. When the Lord himself descends from heaven, the living will be caught up in the clouds with the dead to meet the Lord in the air.