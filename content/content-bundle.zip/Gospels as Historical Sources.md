(Readings are ) Biographies to Jesus

- How many people knew how to read and write
- Do they claim to be eye witness
- Do the different Gospels have agreement or differences

## How many knew how to read and write?
- No more than 5% of population could read and write in Greek and Roman world
- Becuase they lacked:
  - Public education
  - Technological Innovations such as printing press
  - A middle class (mid wealth)

It is not likely that Jesus and his followers knew how to read and write well considering they lived in Galilee, a rural part of Israel filled with small towns and villages. They were also poor as well.

## But there is a Confusion:
- Gospels are written in Greek, while Aramaic is the native language of Jesus and his followers
- Greek was used in large cities, as it was a universal language by Alexander the Great.
- If they knew Greek, they would not have been fluent in it

## What can we say
- Unlikely that Gospels were written close associates of Jesus, nor eyewitness accounts His life, teachings, and death

New Testament Book of Acts describes Jesus' disciples aer "uneducated" and "ordinary" (simple and illiterate)

- Luke's Gospel claims that himself nor others were eyewtiness accounts
