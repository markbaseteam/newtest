
- Philemon is the shortest of Paul's letters
- it’s the only letter (among the letters that most scholars agree  
Paul actually wrote; the so-called “Undisputed Paulines) that is  
addressed primarily to an individual, not to an entire church in  
one geographic area (like Corinth, Galatia, etc.).  

• It focuses much more strongly on a specific social situation, and  
has much less theological/doctrinal discussion, than any of his  
other letters (and if you haven’t read it before, that’s probably  
why...it’s so specific that it’s hard to apply to your own life).  

• And since it’s so unusual, it’s worth wondering about why it was  
one of the Pauline epistles included in the NT (since not  
everything he wrote was included).

- Is the head of a household (which would also  
include a wife, children, and slaves) in which a  
Christian church meets (vv.1-2). Remember,  
churches met in people’s homes until the 4th century,  
when Christianity was legalized in the Roman  
Empire.  
## Who is Philemon?

• Seems to have been converted to Christianity by  
Paul (that’s probably what Paul is referring to in v.19  
when he says “I say nothing about your owing me  
even your own self.”).  

• Probably lives in or around Colossae, based on the  
fact that a number of individuals mentioned in  
Philemon are also mentioned in the Letter to the

- Paul is in prison when he is writing this letter
	- Scholars believe that Paul was improsined in Ephesus during the mid 50's
- ## Onesimus?
- Philemon's slave

========================
-   Philemon is unusual among Paul's letters because it is the shortest, is addressed to an individual, and has less theological/doctrinal discussion than any of his other letters. It is also the only letter that most scholars agree Paul actually wrote.

-   Paul's Letter to Philemon is about his love for all the saints and his faith toward the Lord Jesus. He asks that the sharing of his faith may become effective when you perceive all the good that we may do for Christ.

-   Philemon appealed to Onesimus's mother to send him back to him, saying that he was now useful to both you and him. He wanted to keep him with him, but wanted to do nothing without his mother's consent.

-   If you consider me your partner, welcome him as you would welcome me, and if he has wronged you in any way, charge it to my account. Refresh my heart in Christ, and prepare a guest room for me.

-   Philemon is the head of a household in which a Christian church meets. He seems to have been converted to Christianity by Paul, and he is appealing to the church for his child, Onesimus, whose father he has become during his imprisonment.

-   Paul was imprisoned in Ephesus during the mid-50s, and there are clues scattered throughout his letters that suggest this. He also says he fought "wild beasts" at Ephesus, and almost received a death sentence in Asia.

-   Paul is writing this letter from a prison in Ephesus, which is much closer to Colossae than Rome or Caesarea Maritima. This makes Paul sending Onesimus back to Philemon more plausible.

-   Philemon's slave, Onesimus, was probably named "useful" by his master, and Roman slaves had an unpleasant habit of giving their slaves names like this.

-   Onesimus could have ended up with Paul in prison by sheer coincidence, could have been sent to Paul by Philemon, or could have run away from Philemon and gone to Paul in the hopes that Paul might intercede with his master.

-   Philemon regards Onesimus as useless, and Paul says that O was separated from Phil for a while.

-   Paul suggests that Onesimus might have wronged Phil in some way, so Philemon is asked to do something for him.

-   Paul wants Philemon to allow Onesimus to stay with him in prison to help him, but he prefers to do nothing without Phil's consent. Is it possible that Paul wants Onesimus to become his slave?

-   If Phil decides to keep O, Paul seems to be asking him to change O's status in some way.

-   Paul could be saying that Phil should treat O as a Christian brother while they're worshipping together, or he could still be saying that O should have this status "both in the flesh and in the Lord".

-   Paul wanted Philemon to do whatever he wanted, but he was placing Onesimus in a dangerous position by making it an action punishable by death.

-   Unfortunately, no. Even the details about what Paul wants Phil to do for O are murky enough that both pro-slavery and anti-slavery advocates in the antebellum US appealed to Philemon to justify their position.

-   Paul encourages slaves to remain in the condition in which they were called, and even if they can gain their freedom, make use of their present condition now more than ever.

-   Paul encourages slaves to remain in the condition in which they were called, even if they can gain their freedom. He says that whoever was called in the Lord as a slave is a freed person belonging to the Lord.

-   Paul taught that slaves should obey their earthly masters with fear and trembling, in singleness of heart, as they obey Christ. Master should do the same to slaves, knowing that both have the same Master in heaven.

-   Very few scholars think that Paul wrote this letter, but if he did, it would have been crystal-clear in his letters. If Paul believed that slavery was totally immoral, he probably would have said so.

-   Onesimus, a bishop in Ephesus in the early second century, might have put together a collection of Paul's letters that included the letter to Philemon, and it might have been included because he was personally involved in it.