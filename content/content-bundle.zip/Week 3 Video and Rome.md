##### From Jesus to Christ: The first Christians

**HOUR ONE** examines how Judaism and the Roman empire shaped Jesus' life. Jesus was an ordinary Jewish resident of his time, but new archaeological findings show that Jesus was probably not the humble class="black">(audio excerpt). Nazareth, where he grew up, was about four miles from the cosmopolitan urban center of **[Sepphoris,](https://www.pbs.org/wgbh/pages/frontline/shows/religion/jesus/sepphoris.html)** one of the Roman provincial cities **[(see map)](https://www.pbs.org/wgbh/pages/frontline/shows/religion/maps/arch)**.

While Rome defined one dimension of Jesus' world, the other was symbolized by the great Temple in Jerusalem. Jesus was **[born, lived, and died a Jew,](https://www.pbs.org/wgbh/pages/frontline/shows/religion/jesus/bornliveddied.html)** and he was influenced by the **[diversity and tensions of Judaism](https://www.pbs.org/wgbh/pages/frontline/shows/religion/portrait/judaism.html)** at that time.

Jesus was most likely **[arrested and executed](https://www.pbs.org/wgbh/pages/frontline/shows/religion/jesus/arrest.html)**by Roman authorities whose principal concern was to keep peace in the empire Rome had little tolerance for those it judged disruptive of the Pax Romana, (Roman peace) punishing them in many ways, including **[crucifixion.](https://www.pbs.org/wgbh/pages/frontline/shows/religion/jesus/crucifixion.html)**

The death of Jesus was a Roman act; there was little if any notice taken by Jewish people. Jesus was another victim of the Pax Romana.

##### Greeks, Romans, and Jews
Very wide look at historical context

- Alexander the Great
	- 356-323 BCE
	- [[Philip his father]]
	- Aristotle was his personal tutor
	- Socrates and Plato as well
	- Believes there are races that should rule and should be ruled
	- One of the first mediterranean rulers to be worshiped as a god during his lifetime
	- Created largest empire the Medierranearn  would ever see
	- Introduced Greek city planning in conquered territories
	- Introduced Greek as a universal language throughout these territories
	- ^^ Important constituent parts of Hellenism


- 268 BCE expansion of rome grows
- Interesting to see Roman conquering 

Chrisitans were usually targeted, however for the most part, Romans were tolerant of most religions

Almost all religions were polytheistic (Many gods, not one)

Religious life was mainly about doing things (sacrifices, festivals, etc.), not about believing things.



