- Jews killed Jesus
	- Implausible
- We are not entirely sure what it was that got Jesus killed

- Culprits of Jesus death are the Romans with the assitance of a small group of Jewish authorities
	- Crucifixion was  form of punishment
- Was there even an empty tomb?
- Video:
	  